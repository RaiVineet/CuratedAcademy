﻿using System;


// Model
namespace CuratedAcademy.WebAPI.Models
{

	//Packages
	public class Packages
	{
		public int Id { get; set; }
		public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }

	}

}

