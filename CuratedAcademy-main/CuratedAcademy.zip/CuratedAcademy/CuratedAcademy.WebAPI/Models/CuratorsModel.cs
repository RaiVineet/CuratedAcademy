﻿using System;

//Model
namespace CuratedAcademy.WebAPI.Models
{
    // Curators
    public class Curators
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string PreferredName { get; set; } = string.Empty;
        public string Emailaddress { get; set; } = string.Empty;
    }
}

