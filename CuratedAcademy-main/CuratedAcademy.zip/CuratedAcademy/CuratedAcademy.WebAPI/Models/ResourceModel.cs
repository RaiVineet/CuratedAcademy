﻿using System;

//Model
namespace CuratedAcademy.WebAPI.Models
{
    // Resources
    public class Resources
    {
        public int Id { get; set; }
        public string BlogVedios { get; set; } = string.Empty;
        public string Vediolinks { get; set; } = string.Empty;
    }
}

