﻿using System;
using System.ComponentModel.DataAnnotations; // adding the annotations

namespace CuratedAcademy.WebAPI.Models
{
	public class CuratorsUpdate
	{
        [Required]
        public int Id { get; set; }
        [MaxLength(50)]
        public string Name { get; set; } = string.Empty;
        [MaxLength(50)]
        public string UserName { get; set; } = string.Empty;
        [MaxLength(50)]
        public string PreferredName { get; set; } = string.Empty;
        [MaxLength(50)]
        public string Emailaddress { get; set; } = string.Empty;
    }
}

