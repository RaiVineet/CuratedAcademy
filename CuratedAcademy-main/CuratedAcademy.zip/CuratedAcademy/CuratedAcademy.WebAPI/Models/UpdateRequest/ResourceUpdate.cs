﻿using System;
using System.ComponentModel.DataAnnotations; // adding the annotations

namespace CuratedAcademy.WebAPI.Models
{
	public class ResourceUpdate
	{
        [Required]
        public int Id { get; set; }
        [MaxLength(50)]
        public string BlogVedios { get; set; } = string.Empty;
        [MaxLength(50)]
        public string Vediolinks { get; set; } = string.Empty;
        
	}
}

