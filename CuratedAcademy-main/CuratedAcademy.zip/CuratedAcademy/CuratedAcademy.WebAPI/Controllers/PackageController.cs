﻿using System;
using CuratedAcademy.WebAPI.Models;
using Microsoft.AspNetCore.Mvc;  // via using the mvc

namespace CuratedAcademy.WebAPI.Controllers
{
	[ApiController]
	[Route("api/pakages")]
	public class PackageController : ControllerBase
	{
		private readonly ILogger<PackageController> logger1;
		// Adding The Logger
		public PackageController(ILogger<PackageController> logger)
		{
			logger1 = logger ?? throw new ArgumentNullException(nameof(logger));

			// if the service is not available then we can add the services from the conatinaer directly


		}
		// All The Packages
		[HttpGet]
		public ActionResult GetPackages()
		{
			return new JsonResult(PackagesData.Current.ContentCurators);
		}


		[HttpGet("{id}")]
		// Package By Id
		public ActionResult GetPackageById(int PakageId)
		{

			return new JsonResult(
				PackagesData.Current.ContentCurators.FirstOrDefault(c => c.Id == PakageId)
				);
		}


		


        
		
        // Update The Package

		[HttpPut("{Id}")]
		public ActionResult UpdateThePakage(int PackageId , PackageUpdate packageUpdate)
		{
            var Package = PackagesData.Current.ContentCurators.
				FirstOrDefault(c => c.Id == PackageId);

            if (Package == null)
            {
                return NotFound();
            }

			else if (Package != null)
			{
                Package.Name = packageUpdate.Name;
                Package.Description = packageUpdate.Description;

				return Ok();
            }

			
			return NoContent();
        }

        // Post The Package
        [HttpPost("{Id}")]
        public ActionResult<Packages> PostThePackage
            (int PackageId, [FromBody] PackageCreation packageCreation)
        {
            var Package = PackagesData.Current.ContentCurators.FirstOrDefault(c => c.Id == PackageId);
            if (Package == null)
            {
                logger1.LogInformation($"PackageId {PackageId} Not Found");
                return NotFound();
            }
            if (Package != null)
            {
                var FinalCreation = new Packages()
                {
                    Id = packageCreation.Id,
                    Name = packageCreation.Name,
                    Description = packageCreation.Description,
                };
                PackagesData.Current.ContentCurators.Add(FinalCreation);
                return Ok();
            }
            return NoContent();
        }

        // Delete The Package
        [HttpDelete("{Id}")]
        public ActionResult DeleteThePackage(int PackageId)
        {
            var Package = PackagesData.Current.ContentCurators.FirstOrDefault(c => c.Id == PackageId);
            if (Package == null)
            {
                logger1.LogInformation($"PackageId {PackageId} Not Found");
                return NotFound();
            }
            bool IsDeleted = PackagesData.Current.ContentCurators.Remove(Package);
            if (IsDeleted)
            {
                logger1.LogInformation($" Package {PackageId} Is Deleted");
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }

		


    }
}

