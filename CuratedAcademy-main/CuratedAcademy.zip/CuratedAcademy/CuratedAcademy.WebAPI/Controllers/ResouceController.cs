﻿using System;
using CuratedAcademy.WebAPI.Models;
using Microsoft.AspNetCore.Mvc; // using Mvc


namespace CuratedAcademy.WebAPI.Controllers
{
    [ApiController]
    [Route("api/Resources")]

    public class Resources_Controller : ControllerBase
    {
        [HttpGet]
        public ActionResult GetResources()
		{
			return new JsonResult(ResourcesData.Current.Resources);
		}

        [HttpGet("{Id}")]
        public ActionResult GetResourceById(int ResourceId)
        {

            
            return new JsonResult(ResourcesData.Current.Resources.FirstOrDefault(c => c.Id == ResourceId));

        }
     

        
        // Post The Resources
        [HttpPost("{Id}")]
        public ActionResult<Resources> PostTheResource(int ResouceId , ResourceCreation resourceCreation)
        {
            var resource = ResourcesData.Current.Resources.FirstOrDefault(c => c.Id == ResouceId);
            if(resource == null)
            {
                return NotFound();

            }
            else if(resource != null)
            {
                var finalCreation = new Resources()
                {
                    Id = resourceCreation.Id,
                    BlogVedios = resourceCreation.BlogVedios,
                    Vediolinks = resourceCreation.Vediolinks

                };
                ResourcesData.Current.Resources.Add(finalCreation);
                return Ok();
            }

            return NoContent();
        }
        
        // Update The Resources
        [HttpPut("{Id}")]
        public ActionResult PutTheResource ( int ResourceID , ResourceUpdate resourceUpdate)
        {
            var resource = ResourcesData.Current.Resources.FirstOrDefault(c => c.Id == ResourceID);
            if(resource == null)
            {
                return NotFound();
            }
            else if(resource != null)
            {
                resource.BlogVedios = resourceUpdate.BlogVedios;
                resource.Vediolinks = resourceUpdate.Vediolinks;

                return Ok();
            }

            return NoContent();
        }

        // Delete The Post
        [HttpDelete("{Id}")]
        public ActionResult DeleteThePackage(int PackageId)
        {
            var Package = PackagesData.Current.ContentCurators.FirstOrDefault(c => c.Id == PackageId);
            if (Package == null)
            {
                return NotFound();
            }
            bool IsDeleted = PackagesData.Current.ContentCurators.Remove(Package);
            if (IsDeleted)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }

    }
}

