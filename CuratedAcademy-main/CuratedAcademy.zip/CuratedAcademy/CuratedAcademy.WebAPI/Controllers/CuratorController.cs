﻿using System;
using CuratedAcademy.WebAPI.Models;
using Microsoft.AspNetCore.Mvc; // controller

namespace CuratedAcademy.WebAPI.Controllers
{

	[ApiController]
    [Route("api/Curator")]  // using the curator
    public class CuratorController : ControllerBase
	{
        [HttpGet]
        public ActionResult GetCurators()
        {
            return new JsonResult(CuratorsData.Current.Curators);
        }

        // Get By The Id
        [HttpGet("{Id}")]
        public ActionResult GetCuratorById(int CuratorId)
        {
            return new JsonResult(CuratorsData.Current.Curators.FirstOrDefault(c => c.Id == CuratorId));
        }

        // Update The Curator
        [HttpPut("{Id}")]
        public ActionResult UpdateTheCurators(int CuratorId, CuratorsUpdate curatorsUpdate)
        {
            var Curator = CuratorsData.Current.Curators.FirstOrDefault(c => c.Id == CuratorId);
            if (Curator == null)
            {
                return NotFound();
            }
            if (Curator != null)
            {
                Curator.Id = curatorsUpdate.Id;
                Curator.Name = curatorsUpdate.Name;
                Curator.UserName = curatorsUpdate.PreferredName;
                Curator.PreferredName = curatorsUpdate.PreferredName;
                Curator.Emailaddress = curatorsUpdate.Emailaddress;

                return Ok();
            }

            return NoContent();
        }


        // Post The Curator
       
        [HttpPost("{Id}")]
        public ActionResult<Curators> PostTheCurators(int CuratorId, [FromBody] CuratorsCreation curatorsCreation)
        {
            var Curators = CuratorsData.Current.Curators.FirstOrDefault(c => c.Id == CuratorId);
            if(Curators == null)
            {
                return NotFound();
            }

            if( Curators != null)
            {
                var finalCreation = new Curators()
                {
                    Id = curatorsCreation.Id,
                    Name = curatorsCreation.Name,
                    PreferredName = curatorsCreation.PreferredName,
                    UserName = curatorsCreation.UserName,
                    Emailaddress = curatorsCreation.Emailaddress
                };

                CuratorsData.Current.Curators.Add(finalCreation);
                return Ok();

            }
            return NoContent();

        }

        // Delete The Curator
        [HttpDelete("{Id}")]
        public ActionResult DeleteCurator(int CuratorId)
        {
            var Curators = CuratorsData.Current.Curators.FirstOrDefault(c => c.Id == CuratorId);
            if (Curators == null)
            {
                return NotFound();
            }
            bool IsDeleted = CuratorsData.Current.Curators.Remove(Curators);
            if (IsDeleted)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
    }


}

