﻿using System;
namespace CuratedAcademy.WebAPI
{
	public class EmptyClass
	{
		public EmptyClass()
		{
		}
	}
}

