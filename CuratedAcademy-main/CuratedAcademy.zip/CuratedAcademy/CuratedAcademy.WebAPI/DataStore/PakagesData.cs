﻿using System;
using CuratedAcademy.WebAPI.Models; // data storage

namespace CuratedAcademy.WebAPI
{
	public class PackagesData
	{
		public List<Packages> ContentCurators { get; set; }
		public static PackagesData Current { get; } = new PackagesData();  // new instance

		public PackagesData()
		{
			ContentCurators = new List<Packages>()
			{
				new Packages()
				{
					Id = 1,
					Name = "Vineet Rai",
					Description = " I want to create the content on musical instruments",

                    
				},
				new Packages
                {
					Id = 2,
					Name = " Satish",
					Description = " I want to create the content on the .net courses",

                    

                },
				new Packages
                {
					Id = 3,
					Name = " rajan",
					Description = " I want to create the content for the java courses",

                   
                }

			};
		}
	}
	public class CuratorsData
	{
		public List<Curators> Curators { get; set; }
        public static CuratorsData Current { get; } = new CuratorsData();  // new instance


        public CuratorsData()
		{
			Curators = new List<Curators>()
			{
				new Curators()
				{
					Id = 1,
					Name = " Vineet Rai",
					UserName = " RaiVineet",
					PreferredName = " Vinny",
					Emailaddress = " Vineetrai826@gmail.com"
				},
				new Curators
				{
                    Id = 2,
                    Name = " ",
                    UserName = " ",
                    PreferredName = " ",
                    Emailaddress = " ",

                    
                    
                }

			};
		}
	}
	public class ResourcesData
	{
		public List<Resources> Resources { get; set; }
        public static ResourcesData Current { get; } = new ResourcesData();  // new instance

        public ResourcesData()
		{
			Resources = new List<Resources>()
			{
				 new Resources()
				 {
					Id = 1,
					BlogVedios = "",
					Vediolinks = ""

				 },
				 new Resources
				 {
					 Id = 2,
					 BlogVedios = "",
					 Vediolinks = ""
				 }
			};
		}
	}
}

