using Microsoft.AspNetCore.Mvc;
using CuratedAcademy.WebAPI.DbContexts;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.EntityFrameworkCore;



namespace CuratedAcademy.WebAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            // Changing the logger
            builder.Logging.ClearProviders(); // clearing the logger
            // Adding The Logger
            builder.Logging.AddConsole();

            // Add services to the container.

            builder.Services.AddControllers(option =>
            {
                option.ReturnHttpNotAcceptable = true;  // pop up error msg, if failed to provide the requested format.
            }).AddXmlDataContractSerializerFormatters(); // supporting the xml formate as well with Json.

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddSingleton<FileExtensionContentTypeProvider>();
            
            builder.Services.AddDbContext<PackageInfoContext>
                (DbContextOptions => DbContextOptions.UseSqlite
                (" Data Source = PackageInfo.db"));

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }



            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>{ endpoints.MapControllers();});





            app.Run();
        }
    }
}