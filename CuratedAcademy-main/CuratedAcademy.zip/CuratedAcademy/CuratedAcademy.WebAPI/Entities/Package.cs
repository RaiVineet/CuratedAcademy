﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CuratedAcademy.WebAPI.Entities
{
    //Packages
    public class Package
    {
        // Primary Key
        [Required]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [MaxLength(50)]
        public string Name { get; set; } = string.Empty;
        [MaxLength(200)]
        public string? Description { get; set; }

        [ForeignKey("CuratorId")]
        public Curator? Curator { get; set; }
        public int CuratorId { get; set; }

        // Contructor (Must Have The Name)
        public Package(string name)
        {
            Name = name;
        }
    }

    
}

