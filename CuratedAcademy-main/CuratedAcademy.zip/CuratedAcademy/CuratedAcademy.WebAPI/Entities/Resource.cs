﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CuratedAcademy.WebAPI.Entities
{
    // Resources
    public class Resources
    {
        [Required]


        public int Id { get; set; }
        [MaxLength(300)]
        public string BlogVedios { get; set; } = string.Empty;
        [MaxLength(300)]
        public string Vediolinks { get; set; } = string.Empty;

        // Relationship between the Package And Resources
        [ForeignKey("PackageId")]
        public Package? package { get; set; }
        public int PackageId { get; set; }


    }
}

