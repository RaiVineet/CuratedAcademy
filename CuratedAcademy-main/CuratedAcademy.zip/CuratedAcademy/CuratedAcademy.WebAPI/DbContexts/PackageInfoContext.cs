﻿using System;
using CuratedAcademy.WebAPI.Entities;
using Microsoft.EntityFrameworkCore;

namespace CuratedAcademy.WebAPI.DbContexts
{
	public class PackageInfoContext : DbContext
	{
		public DbSet<Package> packages { get; set; } = null!;
		public DbSet<Resources> resources { get; set; } = null!;

		// ovreriding the PackageInfoContext
		public PackageInfoContext(DbContextOptions<PackageInfoContext>
			options) : base(options){

		}
	}
}

